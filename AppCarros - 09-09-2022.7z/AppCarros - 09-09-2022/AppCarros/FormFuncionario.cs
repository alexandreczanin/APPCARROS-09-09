﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace AppCarros
{
    public partial class FormFuncionario : Form
    {
        public FormFuncionario()
        {
            InitializeComponent();
        }

        private void FormFuncionario_Load(object sender, EventArgs e)
        {
            Funcionario fun = new Funcionario();
            List<Funcionario> funcionarios = fun.listafuncionario();
            DGV.DataSource = funcionarios;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Funcionario funcionario = new Funcionario();
                funcionario.Inserir(txtNome.Text, txtCPF.Text, txtLogin.Text, txtSenha.Text, txtCelular.Text, dtpDtNascimento.Value, txtCep.Text, txtEndereco.Text, txtNumero.Text, txtCidade.Text, txtBairro.Text);
                MessageBox.Show("Funcionário cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> fun = funcionario.listafuncionario();
                DGV.DataSource = fun;
                txtNome.Text = "";
                txtCPF.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Localiza(id);
                txtNome.Text = funcionario.Nome;
                txtCPF.Text = funcionario.CPF;
                txtLogin.Text = funcionario.Login;
                txtSenha.Text = funcionario.Senha;
                txtCelular.Text = funcionario.Celular;
                dtpDtNascimento.Value = Convert.ToDateTime(funcionario.Nascimento);
                txtCep.Text = funcionario.CEP;
                txtEndereco.Text = funcionario.Endereço;
                txtNumero.Text = funcionario.Número;
                txtCidade.Text = funcionario.Cidade;
                txtBairro.Text = funcionario.Bairro;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Atualizar(id, txtNome.Text, txtCPF.Text, txtLogin.Text, txtSenha.Text, txtCelular.Text, dtpDtNascimento.Value, txtCep.Text, txtEndereco.Text, txtNumero.Text, txtCidade.Text, txtBairro.Text);
                MessageBox.Show("Usuário atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> fun = funcionario.listafuncionario();
                DGV.DataSource = fun;
                txtId.Text = "";
                txtNome.Text = "";
                txtCPF.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Exclui(id);
                MessageBox.Show("Usuário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> fun = funcionario.listafuncionario();
                DGV.DataSource = fun;
                txtId.Text = "";
                txtNome.Text = "";
                txtCPF.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://viacep.com.br/ws/" + txtCep.Text + "/json");
            request.AllowAutoRedirect = false;
            HttpWebResponse ChecaServidor = (HttpWebResponse)request.GetResponse();
            if (ChecaServidor.StatusCode != HttpStatusCode.OK)
            {
                MessageBox.Show("Servidor Indisponível!");
                return;
            }
            using (Stream webStream = ChecaServidor.GetResponseStream())
            {
                if (webStream != null)
                {
                    using (StreamReader responseReader = new StreamReader(webStream))
                    {
                        string response = responseReader.ReadToEnd();
                        response = Regex.Replace(response, "[{},]", string.Empty);
                        response = response.Replace("\"", "");

                        String[] substrings = response.Split('\n');

                        int cont = 0;
                        foreach (var substring in substrings)
                        {
                            if (cont == 1)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                if (valor[0] == "  erro")
                                {
                                    MessageBox.Show("CEP não encontrado!");
                                    txtCep.Focus();
                                    return;
                                }
                            }
                            if (cont == 2)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtEndereco.Text = valor[1];
                            }
                            if (cont == 4)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtBairro.Text = valor[1];
                            }
                            if (cont == 5)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtCidade.Text = valor[1];
                            }
                            cont++;
                        }
                    }
                }
            }
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtCPF.Text = "";
            txtLogin.Text = "";
            txtSenha.Text = "";
            txtCelular.Text = "";
            this.dtpDtNascimento.Value = DateTime.Now.Date;
            txtCep.Text = "";
            txtEndereco.Text = "";
            txtNumero.Text = "";
            txtCidade.Text = "";
            txtBairro.Text = "";
        }

        private void dgvFuncionario_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.DGV.Rows[e.RowIndex];
            txtId.Text = row.Cells[0].Value.ToString();
            txtNome.Text = row.Cells[1].Value.ToString();
            txtCPF.Text = row.Cells[2].Value.ToString();
            txtLogin.Text = row.Cells[3].Value.ToString();
            txtSenha.Text = row.Cells[4].Value.ToString();
            txtCelular.Text = row.Cells[5].Value.ToString();
            dtpDtNascimento.Text = row.Cells[6].Value.ToString();
            txtCep.Text = row.Cells[7].Value.ToString();
            txtEndereco.Text = row.Cells[8].Value.ToString();
            txtNumero.Text = row.Cells[9].Value.ToString();
            txtCidade.Text = row.Cells[10].Value.ToString();
            txtBairro.Text = row.Cells[11].Value.ToString();
        }
    }
}
